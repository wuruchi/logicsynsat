There is a line "system(...)" in the main of sol.cpp that needs to be changed for a Linux environment, it is currently configured for MacOS, it is accordingly commented.

Compile using standard g++ sol.cpp

run.sh provides some mass execution.